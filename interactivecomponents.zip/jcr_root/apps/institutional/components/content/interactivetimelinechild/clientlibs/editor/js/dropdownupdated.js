(function(document, $) {
    "use strict";

    // when dialog gets injected
    $(document).on("foundation-contentloaded", function(e) {
        
        // if there is already an inital value make sure the according target element becomes visible
        showHideHandler(this);
    });

    $(document).on("selected", ".cq-dialog-dropdown-showhide-multi", function(e) {
        showHideHandler(this);
    });

    function showHideHandler(ele) {
        console.log("inside show/hide handler --");
         $(ele).find("[data-granite-coral-multifield-name='./timelineItem'] .coral3-Multifield-item .coral3-select").each(function( index ) {
			showHide(this);
         });
      }
       /* el.each(function(i, element) {
            if ($(element).is("coral-select")) {
                // handle Coral3 base drop-down
                Coral.commons.ready(element, function(component) {
                    showHide(component, element);
                    component.on("change", function() {
                        showHide(component, element);
                    });
                });
            } else {
                // handle Coral2 based drop-down
                var component = $(element).data("select");
                if (component) {
                    showHide(component, element);
                }
            }
        })*/


    function showHide(element) {
        // get the selector to find the target elements. its stored as data-.. attribute
        var target = $(element).data("cqDialogDropdownShowhideTarget");
        var $target = $(target);

        var elementIndex = $(element).closest("coral-multifield-item").index();
        console.log("element index : "+elementIndex);
        //console.log($(element))
        if (target) {
            var value;
            if (element.data("showhidetargetvalue")) {
                value = element.data("showhidetargetvalue");
            } else {
                value = "";
            }
            $target.each(function(index) {
                var tarIndex = $(this).closest("coral-multifield-item").index();
                if (elementIndex == tarIndex) {
                    console.log($(this));
                    $(this).not(".hide").addClass("hide");
                    $(this).filter("[data-showhidetargetvalue='" + value + "']").removeClass("hide");
                }
            });
        }
    }

})(document, Granite.$);