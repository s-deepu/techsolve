
"use strict";
use(function () {
    var count = this.value;

    return new Array(Number(count));

});


