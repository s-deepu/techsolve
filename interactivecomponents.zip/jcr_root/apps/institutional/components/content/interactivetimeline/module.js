use(function () {
    request.setAttribute(resource.getPath() + "/one", {
        foo: "Hello World!"
    });
});