function categorySelection(categoryEle, topic){

	$(".categoryContent > button").hasClass("active") ? $(".categoryContent > button").removeClass("active") : "";
	$(".topicContent > button").hasClass("active") ? $(".topicContent > button").removeClass("active") : "";
	$(categoryEle).hasClass("active") ? "" : $(categoryEle).addClass("active");
	
	var topicHeadingEle = $(".topic-heading") ? $(".topic-heading") : "";
    $(topicHeadingEle).hasClass("disabled-heading") ? $(topicHeadingEle).removeClass("disabled-heading") : "";

    $(".next-heading").hasClass("disabled-heading") ? "" : $(".next-heading").addClass("disabled-heading");
    $(".nextContent").length > 0 ? $(".nextContent").addClass("hide") : "" ;

    $(".topicContent").length > 0 ? $(".topicContent").addClass("hide") : "";
    var topicsEle = $(".topicContent."+topic).length > 0 ? $(".topicContent."+topic) : "";
    $(topicsEle).hasClass("hide") ? $(topicsEle).removeClass("hide") : "";

	var categorySection  = $('.category-section-padding');
    var topicSection = $('.topic-section-padding');
    var nextSection = $('.next-section-padding');
    categorySection.hasClass("display-tablet") ? "":categorySection.addClass("display-tablet");
    topicSection.hasClass("display-tablet") ?topicSection.removeClass("display-tablet"):"";
    nextSection.hasClass("display-tablet") ? "": nextSection.addClass("display-tablet");

}

function topicSelection(topicEle, content){

	$(".topicContent > button").hasClass("active") ? $(".topicContent > button").removeClass("active") : "";
	$(topicEle).hasClass("active") ? "" : $(topicEle).addClass("active");
	
    var contentHeadingEle = $(".next-heading") ? $(".next-heading") : "";
    $(contentHeadingEle).hasClass("disabled-heading") ? $(contentHeadingEle).removeClass("disabled-heading") : "";

    $(".nextContent").length > 0 ? $(".nextContent").addClass("hide") : "";
    var nextEle = $(".nextContent."+content).length > 0 ? $(".nextContent."+content) : "";
    $(nextEle).hasClass("hide") ? $(nextEle).removeClass("hide") : "";

	var categorySection  = $('.category-section-padding');
    var topicSection = $('.topic-section-padding');
    var nextSection = $('.next-section-padding');
    
	categorySection.hasClass("display-tablet") ? "": categorySection.addClass("display-tablet");
    topicSection.hasClass("display-tablet") ? "":topicSection.addClass("display-tablet");
    nextSection.hasClass("display-tablet") ? nextSection.removeClass("display-tablet"):"";


}

//swipe Event for category Element
document.addEventListener('touchstart', handleTouchStart, false);        
document.addEventListener('touchmove', handleTouchMove, false);

var xDown = null;                                                        
var yDown = null;

function getTouches(evt) {
  return evt.touches ||             
         evt.originalEvent.touches;
}                                                     

function handleTouchStart(evt) {
    const firstTouch = getTouches(evt)[0];                                      
    xDown = firstTouch.clientX;                                      
    yDown = firstTouch.clientY;                                      
}

function handleTouchMove(evt) {
    if ( ! xDown || ! yDown ) {
        return;
    }

    var xUp = evt.touches[0].clientX;                                    
    var yUp = evt.touches[0].clientY;

    var xDiff = xDown - xUp;
    var yDiff = yDown - yUp;

    var category_column_active;
    var qn_column_active;
    var content_column_active;
    var left_swipe;
    var rigth_swipe;

    var columns  = $('#contactus-sections').children();
    columns.each(function(index,elem){
        var categoryElem;
        if(!elem.classList.contains('display-tablet')){
				var elemId = elem.getAttribute('id');
            if(elemId && elemId.indexOf("category-section") != -1) {
					category_column_active = true;
                	left_swipe = true;
                	right_swipe= false;
            }else if(elemId && elemId.indexOf("topic-section") != -1) {
					qn_column_active = true;
                	left_swipe = true;
                	right_swipe = true;
            }else if(elemId && elemId.indexOf("next-section") != -1) {
					content_column_active = true;
                	left_swipe = false;
                	right_swipe = true;
            }
        }
    });

    if ( Math.abs( xDiff ) > Math.abs( yDiff ) ) {
        if ( xDiff <= 0 ) {
            if(qn_column_active) {
                $('.category-section-padding').hasClass('display-tablet')? $('.category-section-padding').removeClass("display-tablet"):"";
                $('.topic-section-padding').hasClass('display-tablet')? "": $('.topic-section-padding').addClass("display-tablet");
                $('.next-section-padding').hasClass('display-tablet')? "": $('.topic-section-padding').addClass("display-tablet");
            }
            if(content_column_active) {
                $('.topic-section-padding').hasClass('display-tablet')? $('.topic-section-padding').removeClass("display-tablet"):"";
                $('.next-section-padding').hasClass('display-tablet')? "":$('.next-section-padding').addClass("display-tablet");
                $('.category-section-padding').hasClass('display-tablet')?"":$('.category-section-padding').addClass("display-tablet");
            }
        }                       
    }
    /* reset values */
    xDown = null;
    yDown = null;                                             
}
